# Changelog
### **_15/10/17
```MD
1. Version Bump **0.0.7**
______
```
### **_13/10/17_**

```MD
V0.0.5
______

1. Implemented Square Mode.
```

### **_26/09/17_**

```MD
V0.0.5
______

1. Implemented chat.
```

### **_26/09/17_**

```MD
V0.0.5
______

1. Implemented simple leaderboard.
```

### **_26/09/17_**
```MD
V0.0.5
______

1. Improve performance a lot.
2. Optimise drawing.
3. Fix canvas strech bug
4. Add skin compatability (Imgur);
5. Add gameplay options.
6. Add theming.
7. Remove previous text engine.
8. Change fps counter to be more dynamic.
9. Improve css slightly.
10. Add shake effect to heading.

**TODO**


```
